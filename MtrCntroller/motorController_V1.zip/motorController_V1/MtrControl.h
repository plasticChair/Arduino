#define motrPin 10
#define dirPin1 31
#define dirPin2 33
#define motrPotPin A0
#define encPotPin A1
#define ledPin 13

#define EN_CMD         0 //0 is commands are ignored, 1 commands are used 
#define ONE_HZ         1000000
#define ONE_KHZ        100
#define ONE_KHZ_TIME   (1e-3F)
#define TEN_KHZ        100
#define ONEH_HZ        10000
#define CNT2RAD        0.00613592315154256F //(2*pi/(2^10))
#define ADC_RES        1023
#define WRAP_THRESHOLD 20
#define CNTS2RPM       58.6510263929619F  //60/ ((2^10)-1) / 1e-3
#define RPM2RAD_SEC    0.104719755F  // RPM to Rad/sec
#define RAD_SEC2RPM    9.54929659642538F

class MotorController
{
  public:

    // properties
    volatile int   motrCmd         = 0; 
    volatile int   curPosition     = 0;
    volatile int   potHanCnts      = 0;
    volatile int   prevPosition    = 0;
    volatile int   prevEncPosition = 0;
    volatile float mtrRateRPM      = 0.0F;
    volatile float mtrRateRPS      = 0.0F;
    volatile float posnDiffData    = 0;
    volatile int   potMtrCnts      = 0;
    volatile int   potMtrCntsPrev  = 0 ;
    volatile int   tempDiff        = 0;

    // Estimator vars
    volatile float estmX1;
    volatile float estmX2;
    volatile float estmX1_prev;
    volatile float estmX2_prev;
    volatile float estmMotrRateRPS;
    volatile float estmMotrCurrent;

    // methods
    void         init(void);
    void         readSensors(void);
    void         disableMtr(void);
    unsigned int getMtrPosCnt(void);
    float        getMtrRateRPM(void);
    float        getMtrRateRPS(void);
    void         setMtrCmd(int cmd);
      int        getMotrCmd(void);
      int        getDiffCnt(void);
      void       calcEstm(float VoltCnt, float motorSpeed);
      float      getEstmRateRPM(void);
      float      getEstmRateRPS(void);


};

extern MotorController MtrCtrl;

