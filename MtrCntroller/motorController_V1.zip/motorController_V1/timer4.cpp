#include "timer4.h"
TimerFour Timer4;              // preinstatiate

ISR(TIMER4_OVF_vect)          // interrupt service routine that wraps a user defined function supplied by attachInterrupt
{
  Timer4.isrCallback();
}

void TimerFour::initialize(long microseconds)
{
  TCCR4A = 0;                 // clear control register A 
  TCCR4B = _BV(WGM43);        // set mode as phase and frequency correct pwm, stop the timer
  setPeriod(microseconds);
}

void TimerFour::setPeriod(long microseconds)
{
  long cycles = (F_CPU * microseconds) / 2000000;                                // the counter runs backwards after TOP, interrupt is at BOTTOM so divide microseconds by 2
  if(cycles < TMR4_RESOLUTION)              clockSelectBits = _BV(CS40);              // no prescale, full xtal
  else if((cycles >>= 3) < TMR4_RESOLUTION) clockSelectBits = _BV(CS41);              // prescale by /8
  else if((cycles >>= 3) < TMR4_RESOLUTION) clockSelectBits = _BV(CS41) | _BV(CS40);  // prescale by /64
  else if((cycles >>= 2) < TMR4_RESOLUTION) clockSelectBits = _BV(CS42);              // prescale by /246
  else if((cycles >>= 2) < TMR4_RESOLUTION) clockSelectBits = _BV(CS42) | _BV(CS40);  // prescale by /1024
  else        cycles = TMR4_RESOLUTION - 1, clockSelectBits = _BV(CS42) | _BV(CS40);  // request was out of bounds, set as maximum
  ICR4 = pwmPeriod = cycles;                                                     // ICR1 is TOP in p & f correct pwm mode
  TCCR4B &= ~(_BV(CS40) | _BV(CS41) | _BV(CS42));
  TCCR4B |= clockSelectBits;                                                     // reset clock select register
}

void TimerFour::setPwmDuty(char pin, int duty)
{
  unsigned long dutyCycle = pwmPeriod;
  dutyCycle *= duty;
  dutyCycle >>= 10;
  if(pin == 46) OCR4A = dutyCycle;
  if(pin == 44) OCR4B = dutyCycle;
  if(pin == 44) OCR4C = dutyCycle;
}

void TimerFour::pwm(char pin, int duty, long microseconds)  // expects duty cycle to be 10 bit (1024)
{
  if(microseconds > 0) setPeriod(microseconds);
  
  // sets data direction register for pwm output pin
  // activates the output pin
  if(pin == 46) { DDRE |= _BV(PORTL3); TCCR4A |= _BV(COM4A1); }
  if(pin == 44) { DDRE |= _BV(PORTL4); TCCR4A |= _BV(COM4B1); }
  if(pin == 44) { DDRE |= _BV(PORTL4); TCCR4A |= _BV(COM4C1); }
  setPwmDuty(pin, duty);
  start();
}

void TimerFour::disablePwm(char pin)
{
  if(pin == 46) TCCR4A &= ~_BV(COM4A1);   // clear the bit that enables pwm on PE3
  if(pin == 44) TCCR4A &= ~_BV(COM4B1);   // clear the bit that enables pwm on PE4
  if(pin == 44) TCCR4A &= ~_BV(COM4C1);   // clear the bit that enables pwm on PE4
}

void TimerFour::attachInterrupt(void (*isr)(), long microseconds)
{
  if(microseconds > 0) setPeriod(microseconds);
  isrCallback = isr;                                       // register the user's callback with the real ISR
  TIMSK4 = _BV(TOIE4);                                     // sets the timer overflow interrupt enable bit
  sei();                                                   // ensures that interrupts are globally enabled
  start();
}

void TimerFour::detachInterrupt()
{
  TIMSK4 &= ~_BV(TOIE4);                                   // clears the timer overflow interrupt enable bit 
}

void TimerFour::start()
{
  TCCR4B |= clockSelectBits;
}

void TimerFour::stop()
{
  TCCR4B &= ~(_BV(CS40) | _BV(CS41) | _BV(CS42));          // clears all clock selects bits
}

void TimerFour::restart()
{
  TCNT4 = 0;
}

