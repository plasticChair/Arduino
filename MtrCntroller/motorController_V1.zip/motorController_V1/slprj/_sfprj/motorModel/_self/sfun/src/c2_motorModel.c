/* Include files */

#include "motorModel_sfun.h"
#include "c2_motorModel.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "motorModel_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c_with_debugger(S, sfGlobalDebugInstanceStruct);

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization);
static void chart_debug_initialize_data_addresses(SimStruct *S);
static const mxArray* sf_opaque_get_hover_data_for_msg(void *chartInstance,
  int32_T msgSSID);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static const char * c2_debug_family_names[25] = { "numSectors", "sizeSector",
  "WRAP_THRESHOLD", "deadzone_hard", "deadzone_soft_p", "deadzone_soft_n",
  "deadzoneSizeDeg", "extCnt2Deg", "extDeg2Cnt", "deadzoneSizeCnt", "totRevCnt",
  "mtrDir", "curSector", "predictZone", "wrapOffset", "tempDiff", "nargin",
  "nargout", "sampledMtrPos", "diffCounts", "potMtrCntsPrev", "prevSector",
  "predictModePrev", "diffCountsPrev", "predictMode" };

/* Function Declarations */
static void initialize_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance);
static void initialize_params_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance);
static void enable_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance);
static void disable_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance);
static void c2_update_debugger_state_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance);
static const mxArray *get_sim_state_c2_motorModel(SFc2_motorModelInstanceStruct *
  chartInstance);
static void set_sim_state_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_st);
static void finalize_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance);
static void sf_gateway_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance);
static void mdl_start_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance);
static void c2_chartstep_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance);
static void initSimStructsc2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber, uint32_T c2_instanceNumber);
static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData);
static real_T c2_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_b_predictMode, const char_T *c2_identifier, boolean_T
  *c2_svPtr);
static real_T c2_b_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, boolean_T
  *c2_svPtr);
static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static real_T c2_c_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_b_diffCounts, const char_T *c2_identifier);
static real_T c2_d_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static void c2_error(SFc2_motorModelInstanceStruct *chartInstance);
static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static int32_T c2_e_emlrt_marshallIn(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static uint8_T c2_f_emlrt_marshallIn(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_b_is_active_c2_motorModel, const char_T
  *c2_identifier);
static uint8_T c2_g_emlrt_marshallIn(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static int16_T c2__s16_s32_(SFc2_motorModelInstanceStruct *chartInstance,
  int32_T c2_b, uint32_T c2_ssid_src_loc, int32_T c2_offset_src_loc, int32_T
  c2_length_src_loc);
static void init_dsm_address_info(SFc2_motorModelInstanceStruct *chartInstance);
static void init_simulink_io_address(SFc2_motorModelInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  if (sf_is_first_init_cond(chartInstance->S)) {
    initSimStructsc2_motorModel(chartInstance);
    chart_debug_initialize_data_addresses(chartInstance->S);
  }

  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c2_potMtrCntsPrev_not_empty = false;
  chartInstance->c2_prevSector_not_empty = false;
  chartInstance->c2_predictModePrev_not_empty = false;
  chartInstance->c2_diffCountsPrev_not_empty = false;
  chartInstance->c2_predictMode_not_empty = false;
  chartInstance->c2_is_active_c2_motorModel = 0U;
}

static void initialize_params_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void enable_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c2_update_debugger_state_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c2_motorModel(SFc2_motorModelInstanceStruct *
  chartInstance)
{
  const mxArray *c2_st;
  const mxArray *c2_y = NULL;
  real_T c2_hoistedGlobal;
  const mxArray *c2_b_y = NULL;
  real_T c2_b_hoistedGlobal;
  const mxArray *c2_c_y = NULL;
  real_T c2_c_hoistedGlobal;
  const mxArray *c2_d_y = NULL;
  real_T c2_d_hoistedGlobal;
  const mxArray *c2_e_y = NULL;
  real_T c2_e_hoistedGlobal;
  const mxArray *c2_f_y = NULL;
  real_T c2_f_hoistedGlobal;
  const mxArray *c2_g_y = NULL;
  uint8_T c2_g_hoistedGlobal;
  const mxArray *c2_h_y = NULL;
  c2_st = NULL;
  c2_st = NULL;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createcellmatrix(7, 1), false);
  c2_hoistedGlobal = *chartInstance->c2_diffCounts;
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_hoistedGlobal, 0, 0U, 0U, 0U, 0),
                false);
  sf_mex_setcell(c2_y, 0, c2_b_y);
  c2_b_hoistedGlobal = chartInstance->c2_diffCountsPrev;
  c2_c_y = NULL;
  if (!chartInstance->c2_predictMode_not_empty) {
    sf_mex_assign(&c2_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_b_hoistedGlobal, 0, 0U, 0U, 0U,
      0), false);
  }

  sf_mex_setcell(c2_y, 1, c2_c_y);
  c2_c_hoistedGlobal = chartInstance->c2_potMtrCntsPrev;
  c2_d_y = NULL;
  if (!chartInstance->c2_predictMode_not_empty) {
    sf_mex_assign(&c2_d_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_d_y, sf_mex_create("y", &c2_c_hoistedGlobal, 0, 0U, 0U, 0U,
      0), false);
  }

  sf_mex_setcell(c2_y, 2, c2_d_y);
  c2_d_hoistedGlobal = chartInstance->c2_predictMode;
  c2_e_y = NULL;
  if (!chartInstance->c2_predictMode_not_empty) {
    sf_mex_assign(&c2_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_e_y, sf_mex_create("y", &c2_d_hoistedGlobal, 0, 0U, 0U, 0U,
      0), false);
  }

  sf_mex_setcell(c2_y, 3, c2_e_y);
  c2_e_hoistedGlobal = chartInstance->c2_predictModePrev;
  c2_f_y = NULL;
  if (!chartInstance->c2_predictMode_not_empty) {
    sf_mex_assign(&c2_f_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_f_y, sf_mex_create("y", &c2_e_hoistedGlobal, 0, 0U, 0U, 0U,
      0), false);
  }

  sf_mex_setcell(c2_y, 4, c2_f_y);
  c2_f_hoistedGlobal = chartInstance->c2_prevSector;
  c2_g_y = NULL;
  if (!chartInstance->c2_predictMode_not_empty) {
    sf_mex_assign(&c2_g_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_g_y, sf_mex_create("y", &c2_f_hoistedGlobal, 0, 0U, 0U, 0U,
      0), false);
  }

  sf_mex_setcell(c2_y, 5, c2_g_y);
  c2_g_hoistedGlobal = chartInstance->c2_is_active_c2_motorModel;
  c2_h_y = NULL;
  sf_mex_assign(&c2_h_y, sf_mex_create("y", &c2_g_hoistedGlobal, 3, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 6, c2_h_y);
  sf_mex_assign(&c2_st, c2_y, false);
  return c2_st;
}

static void set_sim_state_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_st)
{
  const mxArray *c2_u;
  chartInstance->c2_doneDoubleBufferReInit = true;
  c2_u = sf_mex_dup(c2_st);
  *chartInstance->c2_diffCounts = c2_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("diffCounts", c2_u, 0)), "diffCounts");
  chartInstance->c2_diffCountsPrev = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("diffCountsPrev", c2_u, 1)), "diffCountsPrev",
    &chartInstance->c2_diffCountsPrev_not_empty);
  chartInstance->c2_potMtrCntsPrev = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("potMtrCntsPrev", c2_u, 2)), "potMtrCntsPrev",
    &chartInstance->c2_potMtrCntsPrev_not_empty);
  chartInstance->c2_predictMode = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell("predictMode", c2_u, 3)), "predictMode",
    &chartInstance->c2_predictMode_not_empty);
  chartInstance->c2_predictModePrev = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("predictModePrev", c2_u, 4)), "predictModePrev",
    &chartInstance->c2_predictModePrev_not_empty);
  chartInstance->c2_prevSector = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell("prevSector", c2_u, 5)), "prevSector",
    &chartInstance->c2_prevSector_not_empty);
  chartInstance->c2_is_active_c2_motorModel = c2_f_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell("is_active_c2_motorModel", c2_u, 6)),
     "is_active_c2_motorModel");
  sf_mex_destroy(&c2_u);
  c2_update_debugger_state_c2_motorModel(chartInstance);
  sf_mex_destroy(&c2_st);
}

static void finalize_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void sf_gateway_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c2_sampledMtrPos, 0U, 1U, 0U,
                        c2__s16_s32_(chartInstance, chartInstance->c2_sfEvent,
    0U, 0U, 0U), false);
  chartInstance->c2_sfEvent = CALL_EVENT;
  c2_chartstep_c2_motorModel(chartInstance);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_motorModelMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c2_diffCounts, 1U, 1U, 0U, c2__s16_s32_
                        (chartInstance, chartInstance->c2_sfEvent, 0U, 0U, 0U),
                        false);
}

static void mdl_start_c2_motorModel(SFc2_motorModelInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c2_chartstep_c2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  real_T c2_hoistedGlobal;
  real_T c2_b_sampledMtrPos;
  uint32_T c2_debug_family_var_map[25];
  real_T c2_numSectors;
  real_T c2_sizeSector;
  real_T c2_WRAP_THRESHOLD;
  real_T c2_deadzone_hard;
  real_T c2_deadzone_soft_p;
  real_T c2_deadzone_soft_n;
  real_T c2_deadzoneSizeDeg;
  real_T c2_extCnt2Deg;
  real_T c2_extDeg2Cnt;
  real_T c2_deadzoneSizeCnt;
  real_T c2_totRevCnt;
  real_T c2_mtrDir;
  real_T c2_curSector;
  real_T c2_predictZone;
  real_T c2_wrapOffset;
  real_T c2_tempDiff;
  real_T c2_nargin = 1.0;
  real_T c2_nargout = 1.0;
  real_T c2_b_diffCounts;
  real_T c2_A;
  real_T c2_x;
  real_T c2_b_x;
  real_T c2_y;
  real_T c2_c_x;
  real_T c2_d_x;
  real_T c2_e_x;
  real_T c2_b_hoistedGlobal;
  real_T c2_f_x;
  real_T c2_g_x;
  boolean_T c2_b;
  real_T c2_c_hoistedGlobal;
  real_T c2_h_x;
  real_T c2_i_x;
  real_T c2_j_x;
  real_T c2_b_y;
  real_T c2_d_hoistedGlobal;
  real_T c2_k_x;
  real_T c2_l_x;
  real_T c2_m_x;
  real_T c2_c_y;
  real_T c2_e_hoistedGlobal;
  real_T c2_f_hoistedGlobal;
  real_T c2_g_hoistedGlobal;
  real_T c2_n_x;
  real_T c2_o_x;
  boolean_T c2_b_b;
  real_T c2_h_hoistedGlobal;
  real_T c2_p_x;
  real_T c2_q_x;
  real_T c2_r_x;
  real_T c2_d_y;
  real_T c2_i_hoistedGlobal;
  real_T c2_j_hoistedGlobal;
  real_T c2_k_hoistedGlobal;
  real_T c2_s_x;
  real_T c2_t_x;
  real_T c2_u_x;
  real_T c2_v_x;
  real_T c2_w_x;
  real_T c2_x_x;
  real_T c2_e_y;
  real_T c2_y_x;
  real_T c2_ab_x;
  real_T c2_bb_x;
  boolean_T c2_c_b;
  boolean_T c2_b0;
  real_T c2_cb_x;
  boolean_T c2_d_b;
  boolean_T c2_b1;
  boolean_T c2_e_b;
  boolean_T c2_rEQ0;
  real_T c2_b_A;
  real_T c2_db_x;
  real_T c2_eb_x;
  real_T c2_f_y;
  real_T c2_fb_x;
  real_T c2_gb_x;
  real_T c2_hb_x;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
  c2_hoistedGlobal = *chartInstance->c2_sampledMtrPos;
  c2_b_sampledMtrPos = c2_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 25U, 25U, c2_debug_family_names,
    c2_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_numSectors, 0U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_sizeSector, 1U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_WRAP_THRESHOLD, 2U,
    c2_b_sf_marshallOut, c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_deadzone_hard, 3U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_deadzone_soft_p, 4U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_deadzone_soft_n, 5U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_deadzoneSizeDeg, 6U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_extCnt2Deg, 7U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_extDeg2Cnt, 8U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_deadzoneSizeCnt, 9U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_totRevCnt, 10U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_mtrDir, 11U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_curSector, 12U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_predictZone, 13U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_wrapOffset, 14U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_tempDiff, 15U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargin, 16U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargout, 17U, c2_b_sf_marshallOut,
    c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c2_b_sampledMtrPos, 18U, c2_b_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_diffCounts, 19U,
    c2_b_sf_marshallOut, c2_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&chartInstance->c2_potMtrCntsPrev, 20U,
    c2_sf_marshallOut, c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&chartInstance->c2_prevSector, 21U,
    c2_sf_marshallOut, c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&chartInstance->c2_predictModePrev, 22U,
    c2_sf_marshallOut, c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&chartInstance->c2_diffCountsPrev, 23U,
    c2_sf_marshallOut, c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&chartInstance->c2_predictMode, 24U,
    c2_sf_marshallOut, c2_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 2);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 3);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 5);
  c2_numSectors = 12.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 6);
  c2_sizeSector = 86.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 7);
  c2_WRAP_THRESHOLD = 100.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 8);
  c2_deadzone_hard = 4.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 9);
  c2_deadzone_soft_p = 354.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 10);
  c2_deadzone_soft_n = 6.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 12);
  c2_deadzoneSizeDeg = 12.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 13);
  c2_extCnt2Deg = 0.33724340175953077;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 14);
  c2_extDeg2Cnt = 2.965217391304348;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 15);
  c2_deadzoneSizeCnt = 35.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 16);
  c2_totRevCnt = 1058.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 18);
  c2_mtrDir = 1.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 21);
  c2_A = c2_b_sampledMtrPos;
  c2_x = c2_A;
  c2_b_x = c2_x;
  c2_y = c2_b_x / 86.0;
  c2_c_x = c2_y;
  c2_curSector = c2_c_x;
  c2_d_x = c2_curSector;
  c2_curSector = c2_d_x;
  c2_e_x = c2_curSector;
  c2_curSector = c2_e_x;
  c2_curSector = muDoubleScalarCeil(c2_curSector);
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 25);
  if (CV_EML_IF(0, 1, 0, !chartInstance->c2_predictModePrev_not_empty)) {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 26);
    chartInstance->c2_predictMode = 0.0;
    chartInstance->c2_predictMode_not_empty = true;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 27);
    chartInstance->c2_predictModePrev = 0.0;
    chartInstance->c2_predictModePrev_not_empty = true;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 28);
    chartInstance->c2_diffCountsPrev = 0.0;
    chartInstance->c2_diffCountsPrev_not_empty = true;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 29);
    chartInstance->c2_prevSector = c2_curSector;
    chartInstance->c2_prevSector_not_empty = true;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 30);
    chartInstance->c2_potMtrCntsPrev = c2_b_sampledMtrPos;
    chartInstance->c2_potMtrCntsPrev_not_empty = true;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 36);
  if (CV_EML_COND(0, 1, 0, CV_RELATIONAL_EVAL(4U, 0U, 0, c2_b_sampledMtrPos, 0.0,
        -1, 0U, c2_b_sampledMtrPos == 0.0)) || CV_EML_COND(0, 1, 1,
       CV_RELATIONAL_EVAL(4U, 0U, 1, c2_b_sampledMtrPos, 1023.0, -1, 0U,
                          c2_b_sampledMtrPos == 1023.0))) {
    CV_EML_MCDC(0, 1, 0, true);
    CV_EML_IF(0, 1, 1, true);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 37);
    chartInstance->c2_predictMode = 1.0;
  } else {
    CV_EML_MCDC(0, 1, 0, false);
    CV_EML_IF(0, 1, 1, false);
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 40);
  c2_b_hoistedGlobal = chartInstance->c2_predictModePrev;
  c2_f_x = c2_b_hoistedGlobal;
  c2_g_x = c2_f_x;
  c2_b = muDoubleScalarIsNaN(c2_g_x);
  if (c2_b) {
    c2_error(chartInstance);
  }

  if (CV_EML_IF(0, 1, 2, chartInstance->c2_predictModePrev != 0.0)) {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 41);
    c2_predictZone = c2_deadzoneSizeCnt;
  } else {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 43);
    c2_predictZone = 0.0;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 47);
  c2_c_hoistedGlobal = chartInstance->c2_prevSector;
  c2_h_x = c2_curSector - c2_c_hoistedGlobal;
  c2_i_x = c2_h_x;
  c2_j_x = c2_i_x;
  c2_b_y = muDoubleScalarAbs(c2_j_x);
  c2_d_hoistedGlobal = chartInstance->c2_prevSector;
  c2_k_x = c2_curSector - c2_d_hoistedGlobal;
  c2_l_x = c2_k_x;
  c2_m_x = c2_l_x;
  c2_c_y = muDoubleScalarAbs(c2_m_x);
  if (CV_EML_IF(0, 1, 3, CV_RELATIONAL_EVAL(4U, 0U, 2, c2_b_y, 1.0, -1, 4U,
        c2_c_y > 1.0))) {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 48);
    chartInstance->c2_predictMode = 1.0;
  } else {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 49);
    c2_e_hoistedGlobal = chartInstance->c2_prevSector;
    c2_f_hoistedGlobal = chartInstance->c2_prevSector;
    if (CV_EML_COND(0, 1, 2, CV_RELATIONAL_EVAL(4U, 0U, 3, c2_curSector -
          c2_e_hoistedGlobal, 1.0, -1, 1U, c2_curSector - c2_f_hoistedGlobal !=
          1.0)) && CV_EML_COND(0, 1, 3, CV_RELATIONAL_EVAL(4U, 0U, 4,
          c2_curSector - chartInstance->c2_prevSector, 0.0, -1, 1U, c2_curSector
          - chartInstance->c2_prevSector != 0.0))) {
      CV_EML_MCDC(0, 1, 1, true);
      CV_EML_IF(0, 1, 4, true);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 50);
      chartInstance->c2_predictMode = 1.0;
    } else {
      CV_EML_MCDC(0, 1, 1, false);
      CV_EML_IF(0, 1, 4, false);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 51);
      c2_h_hoistedGlobal = chartInstance->c2_potMtrCntsPrev;
      c2_p_x = c2_b_sampledMtrPos - c2_h_hoistedGlobal;
      c2_q_x = c2_p_x;
      c2_r_x = c2_q_x;
      c2_d_y = muDoubleScalarAbs(c2_r_x);
      c2_j_hoistedGlobal = chartInstance->c2_potMtrCntsPrev;
      c2_s_x = c2_b_sampledMtrPos - c2_j_hoistedGlobal;
      c2_u_x = c2_s_x;
      c2_w_x = c2_u_x;
      c2_e_y = muDoubleScalarAbs(c2_w_x);
      if (CV_EML_COND(0, 1, 4, CV_RELATIONAL_EVAL(4U, 0U, 5, c2_d_y,
            c2_WRAP_THRESHOLD, -1, 4U, c2_e_y > c2_WRAP_THRESHOLD)) &&
          CV_EML_COND(0, 1, 5, CV_RELATIONAL_EVAL(4U, 0U, 6,
            chartInstance->c2_diffCountsPrev, 0.0, -1, 1U,
            chartInstance->c2_diffCountsPrev != 0.0))) {
        CV_EML_MCDC(0, 1, 2, true);
        CV_EML_IF(0, 1, 5, true);
        _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 52);
        chartInstance->c2_predictMode = 1.0;
      } else {
        CV_EML_MCDC(0, 1, 2, false);
        CV_EML_IF(0, 1, 5, false);
      }
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 57);
  c2_g_hoistedGlobal = chartInstance->c2_predictMode;
  c2_n_x = c2_g_hoistedGlobal;
  c2_o_x = c2_n_x;
  c2_b_b = muDoubleScalarIsNaN(c2_o_x);
  if (c2_b_b) {
    c2_error(chartInstance);
  }

  if (CV_EML_IF(0, 1, 6, chartInstance->c2_predictMode != 0.0)) {
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 58);
    c2_i_hoistedGlobal = chartInstance->c2_potMtrCntsPrev;
    c2_k_hoistedGlobal = chartInstance->c2_diffCountsPrev;
    c2_t_x = c2_i_hoistedGlobal + c2_k_hoistedGlobal;
    c2_v_x = c2_t_x;
    c2_x_x = c2_v_x;
    c2_y_x = c2_x_x;
    c2_ab_x = c2_y_x;
    c2_bb_x = c2_ab_x;
    c2_c_b = muDoubleScalarIsInf(c2_bb_x);
    c2_b0 = !c2_c_b;
    c2_cb_x = c2_ab_x;
    c2_d_b = muDoubleScalarIsNaN(c2_cb_x);
    c2_b1 = !c2_d_b;
    c2_e_b = (c2_b0 && c2_b1);
    if (c2_e_b) {
      if (c2_y_x == 0.0) {
        c2_b_sampledMtrPos = 0.0;
      } else {
        c2_b_sampledMtrPos = muDoubleScalarRem(c2_y_x, 1058.0);
        c2_rEQ0 = (c2_b_sampledMtrPos == 0.0);
        if (c2_rEQ0) {
          c2_b_sampledMtrPos = 0.0;
        } else {
          if (c2_y_x < 0.0) {
            c2_b_sampledMtrPos += 1058.0;
          }
        }
      }
    } else {
      c2_b_sampledMtrPos = rtNaN;
    }

    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 59);
    c2_b_A = c2_b_sampledMtrPos;
    c2_db_x = c2_b_A;
    c2_eb_x = c2_db_x;
    c2_f_y = c2_eb_x / 86.0;
    c2_fb_x = c2_f_y;
    c2_curSector = c2_fb_x;
    c2_gb_x = c2_curSector;
    c2_curSector = c2_gb_x;
    c2_hb_x = c2_curSector;
    c2_curSector = c2_hb_x;
    c2_curSector = muDoubleScalarCeil(c2_curSector);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 60);
    c2_predictZone = c2_deadzoneSizeCnt;
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 67);
  if (CV_EML_COND(0, 1, 6, CV_RELATIONAL_EVAL(4U, 0U, 7, c2_curSector, 1.0, -1,
        0U, c2_curSector == 1.0)) && (CV_EML_COND(0, 1, 7, CV_RELATIONAL_EVAL(4U,
         0U, 8, chartInstance->c2_prevSector, 13.0, -1, 0U,
         chartInstance->c2_prevSector == 13.0)) || CV_EML_COND(0, 1, 8,
        CV_RELATIONAL_EVAL(4U, 0U, 9, chartInstance->c2_prevSector, 12.0, -1, 0U,
         chartInstance->c2_prevSector == 12.0)))) {
    CV_EML_MCDC(0, 1, 3, true);
    CV_EML_IF(0, 1, 7, true);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 68);
    c2_wrapOffset = (1023.0 + c2_predictZone) - chartInstance->c2_potMtrCntsPrev;
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 69);
    c2_b_diffCounts = c2_b_sampledMtrPos + c2_wrapOffset;
  } else {
    CV_EML_MCDC(0, 1, 3, false);
    CV_EML_IF(0, 1, 7, false);
    _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 72);
    if ((CV_EML_COND(0, 1, 9, CV_RELATIONAL_EVAL(4U, 0U, 10, c2_curSector, 12.0,
           -1, 0U, c2_curSector == 12.0)) || CV_EML_COND(0, 1, 10,
          CV_RELATIONAL_EVAL(4U, 0U, 11, c2_curSector, 13.0, -1, 0U,
           c2_curSector == 13.0))) && (CV_EML_COND(0, 1, 11, CV_RELATIONAL_EVAL
          (4U, 0U, 12, chartInstance->c2_prevSector, 0.0, -1, 0U,
           chartInstance->c2_prevSector == 0.0)) || CV_EML_COND(0, 1, 12,
          CV_RELATIONAL_EVAL(4U, 0U, 13, chartInstance->c2_prevSector, 1.0, -1,
           0U, chartInstance->c2_prevSector == 1.0)))) {
      CV_EML_MCDC(0, 1, 4, true);
      CV_EML_IF(0, 1, 8, true);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 73);
      c2_wrapOffset = (1023.0 + c2_predictZone) - c2_b_sampledMtrPos;
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 74);
      c2_b_diffCounts = -(c2_wrapOffset + chartInstance->c2_potMtrCntsPrev);
    } else {
      CV_EML_MCDC(0, 1, 4, false);
      CV_EML_IF(0, 1, 8, false);
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 83);
      c2_tempDiff = c2_b_sampledMtrPos - chartInstance->c2_potMtrCntsPrev;
      _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 84);
      c2_b_diffCounts = c2_tempDiff;
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 92);
  chartInstance->c2_predictModePrev = chartInstance->c2_predictMode;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 93);
  chartInstance->c2_diffCountsPrev = c2_b_diffCounts;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 94);
  chartInstance->c2_potMtrCntsPrev = c2_b_sampledMtrPos;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 95);
  chartInstance->c2_prevSector = c2_curSector;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, 96);
  chartInstance->c2_predictMode = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c2_sfEvent, -96);
  _SFD_SYMBOL_SCOPE_POP();
  *chartInstance->c2_diffCounts = c2_b_diffCounts;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
}

static void initSimStructsc2_motorModel(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber, uint32_T c2_instanceNumber)
{
  (void)(c2_machineNumber);
  (void)(c2_chartNumber);
  (void)(c2_instanceNumber);
}

static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  real_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(real_T *)c2_inData;
  c2_y = NULL;
  if (!chartInstance->c2_predictMode_not_empty) {
    sf_mex_assign(&c2_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0), false);
  } else {
    sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
  }

  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static real_T c2_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_b_predictMode, const char_T *c2_identifier, boolean_T
  *c2_svPtr)
{
  real_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_predictMode),
    &c2_thisId, c2_svPtr);
  sf_mex_destroy(&c2_b_predictMode);
  return c2_y;
}

static real_T c2_b_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, boolean_T
  *c2_svPtr)
{
  real_T c2_y;
  real_T c2_d0;
  (void)chartInstance;
  if (mxIsEmpty(c2_u)) {
    *c2_svPtr = false;
  } else {
    *c2_svPtr = true;
    sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d0, 1, 0, 0U, 0, 0U, 0);
    c2_y = c2_d0;
  }

  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_predictMode;
  const char_T *c2_identifier;
  boolean_T *c2_svPtr;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y;
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)chartInstanceVoid;
  c2_b_predictMode = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_svPtr = &chartInstance->c2_predictMode_not_empty;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_predictMode),
    &c2_thisId, c2_svPtr);
  sf_mex_destroy(&c2_b_predictMode);
  *(real_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  real_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(real_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static real_T c2_c_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_b_diffCounts, const char_T *c2_identifier)
{
  real_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_diffCounts),
    &c2_thisId);
  sf_mex_destroy(&c2_b_diffCounts);
  return c2_y;
}

static real_T c2_d_emlrt_marshallIn(SFc2_motorModelInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real_T c2_y;
  real_T c2_d1;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d1, 1, 0, 0U, 0, 0U, 0);
  c2_y = c2_d1;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_diffCounts;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y;
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)chartInstanceVoid;
  c2_b_diffCounts = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_diffCounts),
    &c2_thisId);
  sf_mex_destroy(&c2_b_diffCounts);
  *(real_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

const mxArray *sf_c2_motorModel_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  sf_mex_assign(&c2_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c2_nameCaptureInfo;
}

static void c2_error(SFc2_motorModelInstanceStruct *chartInstance)
{
  const mxArray *c2_y = NULL;
  static char_T c2_cv0[19] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'n', 'o', 'l',
    'o', 'g', 'i', 'c', 'a', 'l', 'n', 'a', 'n' };

  (void)chartInstance;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv0, 10, 0U, 1U, 0U, 2, 1, 19),
                false);
  sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message", 1U,
    1U, 14, c2_y));
}

static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  int32_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(int32_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 6, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static int32_T c2_e_emlrt_marshallIn(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  int32_T c2_y;
  int32_T c2_i0;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_i0, 1, 6, 0U, 0, 0U, 0);
  c2_y = c2_i0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_sfEvent;
  const char_T *c2_identifier;
  emlrtMsgIdentifier c2_thisId;
  int32_T c2_y;
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)chartInstanceVoid;
  c2_b_sfEvent = sf_mex_dup(c2_mxArrayInData);
  c2_identifier = c2_varName;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_sfEvent),
    &c2_thisId);
  sf_mex_destroy(&c2_b_sfEvent);
  *(int32_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static uint8_T c2_f_emlrt_marshallIn(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_b_is_active_c2_motorModel, const char_T
  *c2_identifier)
{
  uint8_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_is_active_c2_motorModel), &c2_thisId);
  sf_mex_destroy(&c2_b_is_active_c2_motorModel);
  return c2_y;
}

static uint8_T c2_g_emlrt_marshallIn(SFc2_motorModelInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_y;
  uint8_T c2_u0;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_u0, 1, 3, 0U, 0, 0U, 0);
  c2_y = c2_u0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static int16_T c2__s16_s32_(SFc2_motorModelInstanceStruct *chartInstance,
  int32_T c2_b, uint32_T c2_ssid_src_loc, int32_T c2_offset_src_loc, int32_T
  c2_length_src_loc)
{
  int16_T c2_a;
  c2_a = (int16_T)c2_b;
  if (c2_a != c2_b) {
    _SFD_OVERFLOW_DETECTION(SFDB_OVERFLOW, 1U, c2_ssid_src_loc,
      c2_offset_src_loc, c2_length_src_loc, 0U, chartInstance->c2_sfEvent, false);
  }

  return c2_a;
}

static void init_dsm_address_info(SFc2_motorModelInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc2_motorModelInstanceStruct
  *chartInstance)
{
  chartInstance->c2_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c2_sampledMtrPos = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c2_diffCounts = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c2_motorModel_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3046727506U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1739247347U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3907960107U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(437548357U);
}

mxArray* sf_c2_motorModel_get_post_codegen_info(void);
mxArray *sf_c2_motorModel_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals", "postCodegenInfo" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1, 1, sizeof
    (autoinheritanceFields)/sizeof(autoinheritanceFields[0]),
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("tlBpyxB5cd0gBsdKlSCGmB");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  {
    mxArray* mxPostCodegenInfo = sf_c2_motorModel_get_post_codegen_info();
    mxSetField(mxAutoinheritanceInfo,0,"postCodegenInfo",mxPostCodegenInfo);
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c2_motorModel_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c2_motorModel_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("pre");
  mxArray *fallbackReason = mxCreateString("hasBreakpoints");
  mxArray *hiddenFallbackType = mxCreateString("none");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c2_motorModel_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

mxArray* sf_c2_motorModel_get_post_codegen_info(void)
{
  const char* fieldNames[] = { "exportedFunctionsUsedByThisChart",
    "exportedFunctionsChecksum" };

  mwSize dims[2] = { 1, 1 };

  mxArray* mxPostCodegenInfo = mxCreateStructArray(2, dims, sizeof(fieldNames)/
    sizeof(fieldNames[0]), fieldNames);

  {
    mxArray* mxExportedFunctionsChecksum = mxCreateString("");
    mwSize exp_dims[2] = { 0, 1 };

    mxArray* mxExportedFunctionsUsedByThisChart = mxCreateCellArray(2, exp_dims);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsUsedByThisChart",
               mxExportedFunctionsUsedByThisChart);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsChecksum",
               mxExportedFunctionsChecksum);
  }

  return mxPostCodegenInfo;
}

static const mxArray *sf_get_sim_state_info_c2_motorModel(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x7'type','srcId','name','auxInfo'{{M[1],M[5],T\"diffCounts\",},{M[4],M[0],T\"diffCountsPrev\",S'l','i','p'{{M1x2[128 142],M[0],}}},{M[4],M[0],T\"potMtrCntsPrev\",S'l','i','p'{{M1x2[86 100],M[0],}}},{M[4],M[0],T\"predictMode\",S'l','i','p'{{M1x2[143 154],M[0],}}},{M[4],M[0],T\"predictModePrev\",S'l','i','p'{{M1x2[112 127],M[0],}}},{M[4],M[0],T\"prevSector\",S'l','i','p'{{M1x2[101 111],M[0],}}},{M[8],M[0],T\"is_active_c2_motorModel\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 7, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_motorModel_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_motorModelInstanceStruct *chartInstance =
      (SFc2_motorModelInstanceStruct *)sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _motorModelMachineNumber_,
           2,
           1,
           1,
           0,
           2,
           0,
           0,
           0,
           0,
           0,
           &chartInstance->chartNumber,
           &chartInstance->instanceNumber,
           (void *)S);

        /* Each instance must initialize its own list of scripts */
        init_script_number_translation(_motorModelMachineNumber_,
          chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,_motorModelMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _motorModelMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"sampledMtrPos");
          _SFD_SET_DATA_PROPS(1,2,0,1,"diffCounts");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,9,0,0,0,0,0,13,5);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,2640);
        _SFD_CV_INIT_EML_IF(0,1,0,738,765,-1,936);
        _SFD_CV_INIT_EML_IF(0,1,1,958,1009,-1,1047);
        _SFD_CV_INIT_EML_IF(0,1,2,1063,1083,1130,1172);
        _SFD_CV_INIT_EML_IF(0,1,3,1190,1226,1262,1347);
        _SFD_CV_INIT_EML_IF(0,1,4,1262,1347,1382,1527);
        _SFD_CV_INIT_EML_IF(0,1,5,1382,1471,-1,1471);
        _SFD_CV_INIT_EML_IF(0,1,6,1556,1571,-1,1776);
        _SFD_CV_INIT_EML_IF(0,1,7,1837,1905,2076,2456);
        _SFD_CV_INIT_EML_IF(0,1,8,2076,2171,2321,2456);

        {
          static int condStart[] = { 962, 986 };

          static int condEnd[] = { 980, 1007 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,0,961,1008,2,0,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1270, 1316 };

          static int condEnd[] = { 1310, 1345 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,1,1269,1346,2,2,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1392, 1450 };

          static int condEnd[] = { 1444, 1469 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,2,1390,1470,2,4,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1842, 1863, 1885 };

          static int condEnd[] = { 1856, 1879, 1901 };

          static int pfixExpr[] = { 0, 1, 2, -2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,3,1841,1904,3,6,&(condStart[0]),&(condEnd[0]),
                                5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2086, 2107, 2131, 2153 };

          static int condEnd[] = { 2101, 2122, 2146, 2168 };

          static int pfixExpr[] = { 0, 1, -2, 2, 3, -2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,4,2084,2170,4,9,&(condStart[0]),&(condEnd[0]),
                                7,&(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML_RELATIONAL(0,1,0,962,980,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,1,986,1007,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,2,1194,1225,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,3,1270,1310,-1,1);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,4,1316,1345,-1,1);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,5,1392,1444,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,6,1450,1469,-1,1);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,7,1842,1856,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,8,1863,1879,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,9,1885,1901,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,10,2086,2101,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,11,2107,2122,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,12,2131,2146,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,13,2153,2168,-1,0);
        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_b_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_b_sf_marshallOut,(MexInFcnForType)c2_b_sf_marshallIn);
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _motorModelMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static void chart_debug_initialize_data_addresses(SimStruct *S)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_motorModelInstanceStruct *chartInstance =
      (SFc2_motorModelInstanceStruct *)sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S)) {
      /* do this only if simulation is starting and after we know the addresses of all data */
      {
        _SFD_SET_DATA_VALUE_PTR(0U, (void *)chartInstance->c2_sampledMtrPos);
        _SFD_SET_DATA_VALUE_PTR(1U, (void *)chartInstance->c2_diffCounts);
      }
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "sxJwdvCEAAPKZDez60fFFs";
}

static void sf_opaque_initialize_c2_motorModel(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc2_motorModelInstanceStruct*) chartInstanceVar
    )->S,0);
  initialize_params_c2_motorModel((SFc2_motorModelInstanceStruct*)
    chartInstanceVar);
  initialize_c2_motorModel((SFc2_motorModelInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c2_motorModel(void *chartInstanceVar)
{
  enable_c2_motorModel((SFc2_motorModelInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c2_motorModel(void *chartInstanceVar)
{
  disable_c2_motorModel((SFc2_motorModelInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c2_motorModel(void *chartInstanceVar)
{
  sf_gateway_c2_motorModel((SFc2_motorModelInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c2_motorModel(SimStruct* S)
{
  return get_sim_state_c2_motorModel((SFc2_motorModelInstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c2_motorModel(SimStruct* S, const mxArray
  *st)
{
  set_sim_state_c2_motorModel((SFc2_motorModelInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_terminate_c2_motorModel(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_motorModelInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_motorModel_optimization_info();
    }

    finalize_c2_motorModel((SFc2_motorModelInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_motorModel((SFc2_motorModelInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_motorModel(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_motorModel((SFc2_motorModelInstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

static void mdlSetWorkWidths_c2_motorModel(SimStruct *S)
{
  /* Set overwritable ports for inplace optimization */
  ssSetStatesModifiedOnlyInUpdate(S, 1);
  ssMdlUpdateIsEmpty(S, 1);
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_motorModel_optimization_info(sim_mode_is_rtw_gen
      (S), sim_mode_is_modelref_sim(S), sim_mode_is_external(S));
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,2);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,1);
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,2,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_set_chart_accesses_machine_info(S, sf_get_instance_specialization(),
      infoStruct, 2);
    sf_update_buildInfo(S, sf_get_instance_specialization(),infoStruct,2);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,2,1);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,2,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 1; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,2);
    sf_register_codegen_names_for_scoped_functions_defined_by_chart(S);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(623471368U));
  ssSetChecksum1(S,(327190275U));
  ssSetChecksum2(S,(2875668064U));
  ssSetChecksum3(S,(3551336014U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSetStateSemanticsClassicAndSynchronous(S, true);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c2_motorModel(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c2_motorModel(SimStruct *S)
{
  SFc2_motorModelInstanceStruct *chartInstance;
  chartInstance = (SFc2_motorModelInstanceStruct *)utMalloc(sizeof
    (SFc2_motorModelInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc2_motorModelInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c2_motorModel;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c2_motorModel;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c2_motorModel;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c2_motorModel;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c2_motorModel;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c2_motorModel;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c2_motorModel;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c2_motorModel;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_motorModel;
  chartInstance->chartInfo.mdlStart = mdlStart_c2_motorModel;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c2_motorModel;
  chartInstance->chartInfo.callGetHoverDataForMsg = NULL;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  chart_debug_initialization(S,1);
  mdl_start_c2_motorModel(chartInstance);
}

void c2_motorModel_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c2_motorModel(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_motorModel(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_motorModel(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_motorModel_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
