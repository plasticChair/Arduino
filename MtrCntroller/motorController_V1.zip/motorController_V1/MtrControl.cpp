#include "MtrControl.h"
#include "Arduino.h"
#include "fastADC.h"
#include "Estm_const.h"

MotorController MtrCtrl;

void MotorController::init(void)
{
  pinMode(ledPin, OUTPUT);
  pinMode(motrPin, OUTPUT);
  pinMode(dirPin1, OUTPUT);
  pinMode(dirPin2, OUTPUT);
  disableMtr();
}

void MotorController::disableMtr(void)
{
  digitalWrite(dirPin1, LOW);
  digitalWrite(dirPin2, HIGH);
  analogWrite(motrPin,  0);
}

void MotorController::readSensors(void)
{
  int diffCounts;
  int posDiff;
  int wrapOffset;

  /* Calc Motor Position and Velocity */
  potMtrCnts = analogReadFast(motrPotPin);
  potHanCnts = analogReadFast(encPotPin);

  tempDiff = potMtrCnts - potMtrCntsPrev ;

  /*  Wrap finder */
  if (tempDiff > WRAP_THRESHOLD) {
    // forward Wrap, 800 - 100 = 700 > 200
    wrapOffset = 1023 - potMtrCnts;
    diffCounts = -(wrapOffset + potMtrCntsPrev);
  }
  else if (tempDiff < -WRAP_THRESHOLD) {
    // Backwards, 60 - 900 = -840 < 200
    wrapOffset = 1023 - potMtrCntsPrev;
    diffCounts = wrapOffset + potMtrCnts;
  }
  else {
    // no motion
    wrapOffset = 0;
    diffCounts = tempDiff;
  }

  mtrRateRPM = ((float)diffCounts) * CNTS2RPM;
  potMtrCntsPrev = potMtrCnts;

}

uint16_t MotorController::getMtrPosCnt(void)
{
  return MotorController::curPosition;
}

float MotorController::getMtrRateRPM(void)
{
  return MotorController::mtrRateRPM;
}

float MotorController::getMtrRateRPS(void)
{
  return MotorController::mtrRateRPM * RPM2RAD_SEC;
}

void MotorController::setMtrCmd(int cmd)
{
  motrCmd = cmd;
  analogWrite(motrPin,  motrCmd);


#if 0
  if (motrCmd > 0)
  {
    digitalWrite(dirPin1, LOW);
    digitalWrite(dirPin2, HIGH);
    analogWrite(motrPin,  motrCmd);
  }
  else
  {
    digitalWrite(dirPin1, HIGH);
    digitalWrite(dirPin2, LOW);
    analogWrite(motrPin,  motrCmd);
  }
#endif
}

int MotorController::getMotrCmd(void)
{
  return MotorController::motrCmd;
}

int MotorController::getDiffCnt(void)
{
  return MotorController::posnDiffData;
}

void MotorController::calcEstm(float Volts, float motorSpeed)
{
  // X1 = motor rate
  // X2 = motor current
  
  estmX1           = A11 * estmX1_prev + A12 * estmX2_prev + B11 * Volts + B12 * motorSpeed;
  estmX2           = A21 * estmX1_prev + A22 * estmX2_prev + B21 * Volts + B22 * motorSpeed;

  estmMotrRateRPS  = C11 * estmX1_prev + C12 * estmX2_prev + D11 * Volts + D12 * motorSpeed;
  estmMotrCurrent  = C21 * estmX1_prev + C22 * estmX2_prev + D21 * Volts + D22 * motorSpeed;

  estmX1_prev      = estmX1;
  estmX2_prev      = estmX2;

}

float MotorController::getEstmRateRPS(void)
{
  return MotorController::estmMotrRateRPS;
}

float MotorController::getEstmRateRPM(void)
{
  return MotorController::estmMotrRateRPS * RAD_SEC2RPM;
}

