import sys
import serial
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QHBoxLayout, QLabel, QSizePolicy, QSlider, QSpacerItem, QVBoxLayout, QWidget
from pyqtgraph.Qt import QtCore
import pyqtgraph as pg
import numpy as np
import string

def arduino_wait():
    msg = ""
    while msg.find("Lets do this") == -1:

        while ser.inWaiting() == 0:
            pass

        msg = recv_data()


def recv_data():
    start_marker = 60
    end_marker = 62

    data = ""
    cur_data = "z"  # any value that is not an end- or start_marker

    # wait for the start character
    while ord(cur_data) != start_marker:
        cur_data = ser.read()

    # save data until the end marker is found
    while ord(cur_data) != end_marker:

        if ord(cur_data) != start_marker:
            data = data + cur_data

        cur_data = ser.read()

    return data


class Slider(QWidget):
    def __init__(self, minimum, maximum, parent=None):
        super(Slider, self).__init__(parent=parent)
        self.verticalLayout = QVBoxLayout(self)
        self.label = QLabel(self)
        self.verticalLayout.addWidget(self.label)
        self.horizontalLayout = QHBoxLayout()
        spacerItem = QSpacerItem(0, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.slider = QSlider(self)
        self.slider.setOrientation(Qt.Vertical)
        self.horizontalLayout.addWidget(self.slider)
        spacerItem1 = QSpacerItem(0, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.resize(self.sizeHint())

        self.minimum = minimum
        self.maximum = maximum
        self.slider.valueChanged.connect(self.setLabelValue)
        self.x = None
        self.setLabelValue(self.slider.value())

    def setLabelValue(self, value):
        self.x = self.minimum + (float(value) / (self.slider.maximum() - self.slider.minimum())) * (self.maximum - self.minimum)
        self.label.setText("{0:.4g}".format(self.x))
    
    def getValue(self):
        return int(self.minimum + (float(self.slider.value()) / (self.slider.maximum() - self.slider.minimum())) * (self.maximum - self.minimum))


class Widget(QWidget):
    def __init__(self, parent=None):
        super(Widget, self).__init__(parent=parent)
        self.horizontalLayout = QHBoxLayout(self)
        
        self.w1 = Slider(0, 255)     
        self.horizontalLayout.addWidget(self.w1)

        #self.w2 = Slider(-1, 1)
        #self.horizontalLayout.addWidget(self.w2)

        #self.w3 = Slider(-10, 10)
        #self.horizontalLayout.addWidget(self.w3)

        #self.w4 = Slider(-10, 10)
        #self.horizontalLayout.addWidget(self.w4)

        self.win = pg.GraphicsWindow(title="Motor Control Plotting")
        self.horizontalLayout.addWidget(self.win)
        self.mainPlot = self.win.addPlot(title="Telemetry Data")
        self.cmd_curve = self.mainPlot.plot(pen='g')
        self.pos_curve = self.mainPlot.plot(pen= 'r')
        self.mainPlot.setYRange(-1000, 1000, padding=0)
        
        
        #self.win2 = pg.GraphicsWindow(title="Motor Control Plotting")
        #self.horizontalLayout.addWidget(self.win2)
        #self.mainPlot2 = self.win2.addPlot(title="Telemetry Data")
                
        self.update()

        self.w1.slider.valueChanged.connect(self.sendCommand)
        #self.w2.slider.valueChanged.connect(self.sendCommand)
        #self.w3.slider.valueChanged.connect(self.sendCommand)
        #self.w4.slider.valueChanged.connect(self.sendCommand)

    def sendCommand(self):
        ser.write(str(self.w1.getValue() + 32767))
        ser.write('\n')


    def update(self):
        global cmd, pos, pltCnt
        retStr = recv_data()
        retStr = string.split(retStr, '!')

        for i in xrange(0, len(retStr)):
            retStr[i] = float(retStr[i])

        cmd = np.append(cmd, np.array([retStr[0]]))
        cmd = np.delete(cmd, 0)
        self.cmd_curve.setData(cmd)

        pos = np.append(pos, np.array([retStr[1]]))
        pos = np.delete(pos, 0)
        self.pos_curve.setData(pos) 



if __name__ == '__main__':
    pltSamples = 500

    pos = np.zeros(pltSamples)
    cmd = np.zeros(pltSamples)

    serPort = "COM4"
    baudRate = 115200
    ser = serial.Serial(serPort, baudRate)
    print "Serial port " + serPort + " opened  Baudrate " + str(baudRate)
    
    arduino_wait()
    print 'Controls Ready!...'

    app = QApplication(sys.argv)
    w = Widget()
    w.show()

    timer = QtCore.QTimer()
    timer.timeout.connect(w.update)
    timer.start(0)

    app.exec_()
