clc;
clear;
close all;


% (J)     moment of inertia of the rotor     0.01 kg.m^2
% (b)     motor viscous friction constant    0.1 N.m.s
% (Ke)    electromotive force constant       0.01 V/rad/sec
% (Kt)    motor torque constant              0.01 N.m/Amp
% (R)     electric resistance                1 Ohm
% (L)     electric inductance                0.5 H

% Define coefficients
J = 0.01; % Motor inertia [kg-m^2]
b = 0.1;  % Motor damping or viscous friction [Nm/rad/s]
K = 0.01; % Ke = Kt

% Values below this line are measured:
R = 10.6;    %ohms
L = 4.09e-3; %henries

% Controller gains
Kp = 100;
Ki = 200;
Kd = 10;
s = tf('s');

% x1 = thetadotm (motor speed) (Rad/sec)
% x2 = motor current (A)
% x3 = theta( motor position) (rad)
% u1 = Voltage

A = [-b/J   K/J   0
    -K/L   -R/L   0
       1      0   0];
B = [0
    1/L
    0];
C = [1 0 0
    0  1  0
    0  0  1];

D = zeros(3,1);

Ts            = 1.0e-03;
Tend          = 4;

PID_c         = Kp + Ki/s + Kd*s;
PID_d       = c2d(PID_c, Ts, 'tustin');
[pid_d_num, pid_d_den] = tfdata(PID_d, 'v');

motor_ss_c    = ss(A,B,C,D);
motor_ss_d    = c2d(motor_ss_c, Ts, 'tustin');
motor_ss_d_cl = feedback(PID_d*motor_ss_d(1,:,:), 1);

A = A(1:2,1:2);
B = B(1:2);
C = C(1,1:2);
D = [0];

t = 0:Ts:25;
radPerSec_cmd = 1*sin(t);
figure(1);
lsim(motor_ss_d_cl, radPerSec_cmd, t)
figure(2);
bode(motor_ss_d_cl);
xlabel('Time (sec)');
ylabel('Motor Speed (rad/sec)');

id = idpoly(PID_d);

% Define estimator pole locations
z1 = .707;
w1 = 100*2*pi;

P = [roots([1 2*z1*w1 w1^2])]; 

% Use pole placement to find observer gain matrix
K = place(A',C',P);

% Create estimator matrices
Aest = A - K'*C;
Best = [B K'];
Cest = [1, 0; 0, 1];
Dest = zeros(2,2);

motor_est_ss = ss(Aest,Best,Cest,Dest);
motor_est_ss_d = c2d(motor_est_ss, Ts,'tustin'); 

ESTD_A      = motor_est_ss_d.A;
ESTD_B      = motor_est_ss_d.B;
ESTD_C      = motor_est_ss_d.C;
ESTD_D      = motor_est_ss_d.D;

% Determine Estimator Constants for DMCA
A11    = ESTD_A(1,1);
A12    = ESTD_A(1,2);
A21    = ESTD_A(2,1);
A22    = ESTD_A(2,2);

B11    = ESTD_B(1,1);
B12    = ESTD_B(1,2);
B21    = ESTD_B(2,1);
B22    = ESTD_B(2,2);  
 
C11    = ESTD_C(1,1);
C12    = ESTD_C(1,2);
C21    = ESTD_C(2,1);
C22    = ESTD_C(2,2);

D11    = ESTD_D(1,1);
D12    = ESTD_D(1,2);
D21    = ESTD_D(2,1);
D22    = ESTD_D(2,2);

%% Estm Header with matrix constants
fclose('all');
filename = 'Estm_const.h';
fid =fopen(filename,'w');
fclose(fid);
fid = fopen(filename,'a');

fprintf(fid,'#define A11      %dF \r\n', A11); 
fprintf(fid,'#define A12      %dF \r\n', A12); 
fprintf(fid,'#define A21      %dF \r\n', A21); 
fprintf(fid,'#define A22      %dF \r\n', A22); 

fprintf(fid,'#define B11      %dF \r\n', B11); 
fprintf(fid,'#define B12      %dF \r\n', B12); 
fprintf(fid,'#define B21      %dF \r\n', B21); 
fprintf(fid,'#define B22      %dF \r\n', B22); 

fprintf(fid,'#define C11      %dF \r\n', C11); 
fprintf(fid,'#define C12      %dF \r\n', C12); 
fprintf(fid,'#define C21      %dF \r\n', C21); 
fprintf(fid,'#define C22      %dF \r\n', C22); 

fprintf(fid,'#define D11      %dF \r\n', D11); 
fprintf(fid,'#define D12      %dF \r\n', D12); 
fprintf(fid,'#define D21      %dF \r\n', D21); 
fprintf(fid,'#define D22      %dF \r\n', D22); 

fprintf(fid,'#define CNT2VOLT %dF \r\n', 12/255); 


fclose('all');










